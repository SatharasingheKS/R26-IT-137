package com.cy.beaconme;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.appcompat.widget.PopupMenu;

import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

import java.util.List;

public final class MainActivity extends AppCompatActivity implements DeviceAdapter.Listener {

    private DeviceStore store;
    private DeviceAdapter adapter;
    private TextView textEmpty;
    private RecyclerView recycler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        store = new DeviceStore(this);
        textEmpty = findViewById(R.id.textEmpty);
        recycler = findViewById(R.id.recyclerDevices);
        recycler.setLayoutManager(new LinearLayoutManager(this));
        adapter = new DeviceAdapter(this);
        recycler.setAdapter(adapter);

        ExtendedFloatingActionButton fab = findViewById(R.id.fabAdd);
        fab.setOnClickListener(v -> showDeviceDialog(null));

        refreshList();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshList();
    }

    private void refreshList() {
        List<IoTDevice> list = store.loadAll();
        adapter.setItems(list);
        textEmpty.setVisibility(list.isEmpty() ? View.VISIBLE : View.GONE);
        recycler.setVisibility(list.isEmpty() ? View.GONE : View.VISIBLE);
    }

    @Override
    public void onDeviceClick(@NonNull IoTDevice device) {
        Intent i = new Intent(this, DeviceWebActivity.class);
        i.putExtra(DeviceWebActivity.EXTRA_TITLE, device.getName());
        i.putExtra(DeviceWebActivity.EXTRA_URL, device.getUrl());
        startActivity(i);
    }

    @Override
    public void onDeviceMenu(@NonNull IoTDevice device, @NonNull View anchor) {
        PopupMenu popup = new PopupMenu(this, anchor);
        popup.getMenu().add(0, 1, 0, R.string.menu_edit);
        popup.getMenu().add(0, 2, 0, R.string.menu_delete);
        popup.setOnMenuItemClickListener(item -> {
            if (item.getItemId() == 1) {
                showDeviceDialog(device);
                return true;
            }
            if (item.getItemId() == 2) {
                confirmDelete(device);
                return true;
            }
            return false;
        });
        popup.show();
    }

    private void confirmDelete(@NonNull IoTDevice device) {
        new MaterialAlertDialogBuilder(this)
                .setTitle(R.string.delete_confirm_title)
                .setMessage(R.string.delete_confirm_message)
                .setNegativeButton(R.string.cancel, null)
                .setPositiveButton(R.string.menu_delete, (d, w) -> {
                    store.deleteById(device.getId());
                    refreshList();
                })
                .show();
    }

    private void showDeviceDialog(@Nullable IoTDevice existing) {
        View form = LayoutInflater.from(this).inflate(R.layout.dialog_add_device, null, false);
        TextInputLayout layoutName = form.findViewById(R.id.layoutName);
        TextInputLayout layoutUrl = form.findViewById(R.id.layoutUrl);
        TextInputEditText inputName = form.findViewById(R.id.inputName);
        TextInputEditText inputUrl = form.findViewById(R.id.inputUrl);

        if (existing != null) {
            inputName.setText(existing.getName());
            inputUrl.setText(existing.getUrl());
        }

        AlertDialog dialog = new MaterialAlertDialogBuilder(this)
                .setTitle(existing == null ? R.string.dialog_add_title : R.string.dialog_edit_title)
                .setView(form)
                .setNegativeButton(R.string.cancel, null)
                .setPositiveButton(R.string.save, null)
                .create();

        dialog.setOnShowListener(d -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            layoutName.setError(null);
            layoutUrl.setError(null);
            String name = String.valueOf(inputName.getText()).trim();
            String urlRaw = String.valueOf(inputUrl.getText()).trim();
            if (name.isEmpty()) {
                layoutName.setError(getString(R.string.error_name_required));
                return;
            }
            if (urlRaw.isEmpty()) {
                layoutUrl.setError(getString(R.string.error_url_required));
                return;
            }
            if (existing == null) {
                store.upsert(IoTDevice.createNew(name, urlRaw));
            } else {
                store.upsert(existing.withUpdates(name, urlRaw));
            }
            refreshList();
            dialog.dismiss();
        }));

        dialog.show();
    }
}
